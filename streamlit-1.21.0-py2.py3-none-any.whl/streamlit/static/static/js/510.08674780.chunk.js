/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkstreamlit_browser"] = self["webpackChunkstreamlit_browser"] || []).push([[510],{

/***/ 13100:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("// ESM COMPAT FLAG\n__webpack_require__.r(__webpack_exports__);\n\n// EXPORTS\n__webpack_require__.d(__webpack_exports__, {\n  \"default\": function() { return /* reexport */ GraphVizChart_GraphVizChart; }\n});\n\n// EXTERNAL MODULE: ./node_modules/react/index.js\nvar react = __webpack_require__(47313);\n// EXTERNAL MODULE: ./node_modules/d3/src/index.js + 82 modules\nvar src = __webpack_require__(2417);\n// EXTERNAL MODULE: ./node_modules/d3-graphviz/build/d3-graphviz.js\nvar d3_graphviz = __webpack_require__(94178);\n// EXTERNAL MODULE: ./src/lib/log.ts\nvar log = __webpack_require__(72599);\n// EXTERNAL MODULE: ./src/hocs/withFullScreenWrapper/index.tsx + 6 modules\nvar withFullScreenWrapper = __webpack_require__(26419);\n// EXTERNAL MODULE: ./node_modules/@emotion/styled/base/dist/emotion-styled-base.browser.esm.js\nvar emotion_styled_base_browser_esm = __webpack_require__(47167);\n;// CONCATENATED MODULE: ./src/components/elements/GraphVizChart/styled-components.ts\n/**\n * Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022)\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\");\n * you may not use this file except in compliance with the License.\n * You may obtain a copy of the License at\n *\n *     http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS,\n * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\n * See the License for the specific language governing permissions and\n * limitations under the License.\n */var StyledGraphVizChart=/*#__PURE__*/(0,emotion_styled_base_browser_esm/* default */.Z)(\"div\", true?{target:\"e1p558ko0\"}:0)(function(_ref){var theme=_ref.theme;return{\"& *\":{fontFamily:theme.genericFonts.bodyFont,// Font sizes inside the SVG element are getting huge for some reason.\n// Hacking together a number by eyeballing it:\n// 12px in the SVG looks like 1rem outside, so 9.6px ~= 0.8rem.\nfontSize:\"9.6px\"},\"& svg\":{maxWidth:\"100%\"}};}, true?\"\":0);\n// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js\nvar jsx_runtime = __webpack_require__(46417);\n;// CONCATENATED MODULE: ./src/components/elements/GraphVizChart/GraphVizChart.tsx\n/**\n * Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022)\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\");\n * you may not use this file except in compliance with the License.\n * You may obtain a copy of the License at\n *\n *     http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS,\n * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\n * See the License for the specific language governing permissions and\n * limitations under the License.\n */// Use d3Graphviz in a dummy expression so the library actually gets loaded.\n// This way it registers itself in d3 as a plugin at this point.\nvar dummyGraphviz=d3_graphviz.graphviz;dummyGraphviz;// eslint-disable-line @typescript-eslint/no-unused-expressions\nfunction GraphVizChart(_ref){var propWidth=_ref.width,element=_ref.element,propHeight=_ref.height;var chartId=\"graphviz-chart-\".concat(element.elementId);var originalHeight=0;var originalWidth=0;var getChartData=function getChartData(){return element.spec;};var getChartDimensions=function getChartDimensions(){var chartWidth=originalWidth;var chartHeight=originalHeight;if(propHeight){// fullscreen\nchartWidth=propWidth;chartHeight=propHeight;}else if(element.useContainerWidth){chartWidth=propWidth;}return{chartWidth:chartWidth,chartHeight:chartHeight};};var updateChart=function updateChart(){try{// Layout and render the graph\nvar graph=(0,d3_graphviz.graphviz)(\"#\".concat(chartId)).zoom(false).fit(true).scale(1).renderDot(getChartData()).on(\"end\",function(){var node=(0,src/* select */.Ys)(\"#\".concat(chartId,\" > svg\")).node();if(node){originalHeight=node.getBBox().height;originalWidth=node.getBBox().width;}});var _getChartDimensions=getChartDimensions(),chartHeight=_getChartDimensions.chartHeight,chartWidth=_getChartDimensions.chartWidth;if(chartHeight>0){// Override or reset the graph height\ngraph.height(chartHeight);}if(chartWidth>0){// Override or reset the graph width\ngraph.width(chartWidth);}}catch(error){(0,log/* logError */.H)(error);}};(0,react.useEffect)(function(){updateChart();});var elementDimensions=getChartDimensions();var width=elementDimensions.chartWidth?elementDimensions.chartWidth:propWidth;var height=elementDimensions.chartHeight?elementDimensions.chartHeight:propHeight;return/*#__PURE__*/(0,jsx_runtime.jsx)(StyledGraphVizChart,{className:\"graphviz stGraphVizChart\",id:chartId,style:{width:width,height:height}});}/* harmony default export */ var GraphVizChart_GraphVizChart = ((0,withFullScreenWrapper/* default */.Z)(GraphVizChart));\n;// CONCATENATED MODULE: ./src/components/elements/GraphVizChart/index.tsx\n/**\n * Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022)\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\");\n * you may not use this file except in compliance with the License.\n * You may obtain a copy of the License at\n *\n *     http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS,\n * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\n * See the License for the specific language governing permissions and\n * limitations under the License.\n */\n\n//# sourceURL=components/elements/GraphVizChart/index.tsx%7C089d9e108816f0a9472f08e41316f2b5");

/***/ }),

/***/ 46825:
/***/ (function() {

eval("/* (ignored) */\n\n//# sourceURL=../ignored%7C/Users/tszerszen/Documents/streamlit/frontend/node_modules/viz.js%7Ccrypto");

/***/ }),

/***/ 35159:
/***/ (function() {

eval("/* (ignored) */\n\n//# sourceURL=../ignored%7C/Users/tszerszen/Documents/streamlit/frontend/node_modules/viz.js%7Cfs");

/***/ }),

/***/ 75701:
/***/ (function() {

eval("/* (ignored) */\n\n//# sourceURL=../ignored%7C/Users/tszerszen/Documents/streamlit/frontend/node_modules/viz.js%7Cpath");

/***/ })

}]);