"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkstreamlit_browser"] = self["webpackChunkstreamlit_browser"] || []).push([[248],{

/***/ 80248:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("// ESM COMPAT FLAG\n__webpack_require__.r(__webpack_exports__);\n\n// EXPORTS\n__webpack_require__.d(__webpack_exports__, {\n  \"default\": function() { return /* reexport */ Audio; }\n});\n\n// EXTERNAL MODULE: ./node_modules/react/index.js\nvar react = __webpack_require__(47313);\n// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js\nvar jsx_runtime = __webpack_require__(46417);\n;// CONCATENATED MODULE: ./src/components/elements/Audio/Audio.tsx\n/**\n * Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022)\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\");\n * you may not use this file except in compliance with the License.\n * You may obtain a copy of the License at\n *\n *     http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS,\n * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\n * See the License for the specific language governing permissions and\n * limitations under the License.\n */function Audio(_ref){var element=_ref.element,width=_ref.width,endpoints=_ref.endpoints;var audioRef=(0,react.useRef)(null);(0,react.useEffect)(function(){if(audioRef.current){audioRef.current.currentTime=element.startTime;}},[element.startTime]);var uri=endpoints.buildMediaURL(element.url);return/*#__PURE__*/(0,jsx_runtime.jsx)(\"audio\",{id:\"audio\",ref:audioRef,controls:true,src:uri,className:\"stAudio\",style:{width:width}});}\n;// CONCATENATED MODULE: ./src/components/elements/Audio/index.tsx\n/**\n * Copyright (c) Streamlit Inc. (2018-2022) Snowflake Inc. (2022)\n *\n * Licensed under the Apache License, Version 2.0 (the \"License\");\n * you may not use this file except in compliance with the License.\n * You may obtain a copy of the License at\n *\n *     http://www.apache.org/licenses/LICENSE-2.0\n *\n * Unless required by applicable law or agreed to in writing, software\n * distributed under the License is distributed on an \"AS IS\" BASIS,\n * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.\n * See the License for the specific language governing permissions and\n * limitations under the License.\n */\n\n//# sourceURL=components/elements/Audio/index.tsx%7Cd7b707a60cac11a6c30e6e81f6fe490f");

/***/ })

}]);